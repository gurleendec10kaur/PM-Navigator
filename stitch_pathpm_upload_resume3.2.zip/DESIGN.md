# The Career Architect: A Signature Design System

## 1. Overview & Creative North Star
This design system is built upon the vision of **"The Career Architect."** In the world of high-stakes PM coaching, users don't need a generic dashboard; they need a digital blueprint—a space that feels as precise, structured, and intentional as the careers they are building.

We move beyond "Standard SaaS" by rejecting the rigid grid in favor of **Sophisticated Asymmetry**. By utilizing overlapping editorial layouts, high-contrast typography scales, and a departure from traditional borders, we create an environment of professional empowerment. The UI doesn't just display data; it curates progress through depth, light, and "breathable" white space.

---

## 2. Color & Surface Philosophy
Our palette balances the clinical precision of **Primary Teal (#006A62)** with the authoritative weight of **Dark Navy (Secondary #4E5E80)** and the aspirational energy of **Accent Gold (Tertiary #855300)**.

### The "No-Line" Rule
Standard 1px solid borders are strictly prohibited for sectioning. Structural boundaries must be defined solely through:
1.  **Background Color Shifts:** Transitions from `surface` to `surface-container-low`.
2.  **Tonal Depth:** Placing a `surface-container-lowest` (pure white) card on a `surface-container` background.
3.  **Negative Space:** Using the Spacing Scale (specifically `8`, `12`, and `16`) to create mental groupings.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of premium materials. 
*   **The Foundation:** Use `surface-container-low` (#F0F4F8) for the main application canvas.
*   **The Blueprint:** Use `surface-container-lowest` (#FFFFFF) for primary interactive cards.
*   **The Detail:** Use `surface-container-high` for nested elements like sidebar widgets or code snippets.

### The "Glass & Signature Texture" Rule
To elevate the experience, floating elements (modals, dropdowns) should utilize **Glassmorphism**. Use `surface` colors at 80% opacity with a `20px` backdrop-blur. 
*   **Signature Gradient:** For Hero CTAs and high-impact "Growth Moments," use a subtle linear gradient from `primary` (#006A62) to `primary-container` (#00B4A6) at a 135-degree angle to provide a "lit from within" professional polish.

---

## 3. Typography: Editorial Authority
We use **Inter** not as a utility font, but as an editorial tool. The contrast between massive `display` scales and tight `label` scales creates an authoritative hierarchy.

*   **Display & Headlines (Bold 700):** These are the "Architect’s Markers." Use `display-md` for landing moments and `headline-sm` for dashboard headers. They should feel heavy, permanent, and confident.
*   **Title & Body (Regular 400):** Use `title-md` for card headings to ensure legibility. Body text uses `body-md` (0.875rem) with generous line-height (1.6) to prevent data fatigue.
*   **Labels (Semi-bold 600):** All `label-md` elements should use `on-surface-variant` colors to distinguish metadata from actionable content.

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows are often a crutch for poor layout. In this system, depth is earned through layering.

*   **The Layering Principle:** Rather than "lifting" a card with a shadow, "sink" the background. Place a `surface-container-lowest` card on a `surface-container` background. The 16px (`xl`) radius provides the necessary soft edge to imply depth.
*   **Ambient Shadows:** If an element must float (e.g., a "Career Roadmap" popover), use an ultra-diffused shadow: `0 12px 48px rgba(23, 28, 31, 0.06)`. The tint is derived from the `on-surface` color, never pure black.
*   **The "Ghost Border" Fallback:** If accessibility requires a container edge (e.g., in high-contrast modes), use a `1px` stroke of `outline-variant` at **15% opacity**. It should be felt, not seen.

---

## 5. Signature Components

### Buttons (Architectural Anchors)
*   **Primary:** 48px height, `primary` background, `on-primary` text. Radius: `md` (12px). 
*   **Secondary:** Ghost-style. No background. `1px` Ghost Border (`outline-variant` @ 20%). Text: `primary`.
*   **Tertiary:** For "Danger" or "Alternative" paths. Use `surface-variant` background with `on-surface` text. No border.

### Precision Cards
*   **Style:** No borders. `16px` (xl) radius. 
*   **Content:** Never use divider lines. Separate "Current Focus" from "Upcoming Tasks" using a `spacing-6` (1.5rem) vertical gap or a subtle background shift to `surface-container-high`.

### The "Milestone" Chip
*   **Context:** Used for PM certifications or skill badges.
*   **Style:** `tertiary-container` background with `on-tertiary-container` text. Small `0.25rem` radius to feel like a "tag" or "stamp" of approval.

### Data Inputs
*   **State:** Default state uses `surface-container-highest` as a subtle fill rather than an outline.
*   **Focus State:** Transition to a `1px` solid `primary` border with a `4px` soft outer glow of `primary_fixed` at 30% opacity.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical layouts. If a card is on the left, let the supporting text on the right sit 24px higher to create a "stepping stone" visual flow.
*   **Do** use the `Accent Gold` (Tertiary) sparingly—only for "Success" states, "Promotion" milestones, or high-value CTAs.
*   **Do** embrace white space. If you think there is enough space, add `8px` more.

### Don’t:
*   **Don't** use 1px solid lines to separate list items. Use vertical padding and tonal shifts.
*   **Don't** use standard "Drop Shadows." If it looks like a 2010 SaaS app, it’s too heavy.
*   **Don't** use more than one `display-lg` heading per page. It should be a singular, monumental statement.